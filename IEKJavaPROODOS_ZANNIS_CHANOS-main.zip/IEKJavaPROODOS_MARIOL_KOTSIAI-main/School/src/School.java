
public class School {

	public static void main(String[] args) {
		
		Teacher t1 = new Teacher();
		t1.setFirstName("Mariol");
		t1.setLaststName("Kotsiai");
		t1.setAMKA("08080301651");
		t1.setSubject("Mathimatika");
		t1.printInfo();
		
		Teacher t2 = new Teacher();
		t2.setFirstName("Mariol");
		t2.setLaststName("Kotsiai");
		t2.setAMKA("08080301651");
		t2.setSubject("Mathimatika");
		t2.printInfo();
		
		Teacher t3 = new Teacher();
		t3.setFirstName("Mariol");
		t3.setLaststName("Kotsiai");
		t3.setAMKA("08080301651");
		t3.setSubject("Mathimatika");
		t3.printInfo();
		
		Teacher t4 = new Teacher();
		t4.setFirstName("Mariol");
		t4.setLaststName("Kotsiai");
		t4.setAMKA("08080301651");
		t4.setSubject("Mathimatika");
		t4.printInfo();
		
		Teacher t5 = new Teacher();
		t5.setFirstName("Mariol");
		t5.setLaststName("Kotsiai");
		t5.setAMKA("08080301651");
		t5.setSubject("Mathimatika");
		t5.printInfo();
		
		Classroom c1 = new Classroom();
		c1.setClassCode("E1");
		c1.setClassDesc("Ergastirio I");
		c1.printInfo();
		
		Classroom c2 = new Classroom();
		c2.setClassCode("E2");
		c2.setClassDesc("Ergastirio II");
		c2.printInfo();

		Classroom c3 = new Classroom();
		c3.setClassCode("E3");
		c3.setClassDesc("Ergastirio III");
		c3.printInfo();
		
		Classroom c4 = new Classroom();
		c4.setClassCode("E4");
		c4.setClassDesc("Ergastirio IV");
		c4.printInfo();
		
		Classroom c5 = new Classroom();
		c5.setClassCode("E5");
		c5.setClassDesc("Ergastirio V");
		c5.printInfo();
		
		Subject s1 = new Subject();
		s1.setSubDesc("Algorithms and data structures III");
		s1.setSubCode("M1");
		s1.setClassroom("E4");
		s1.printInfo();
		
		Subject s2 = new Subject();
		s2.setSubDesc("Computer architecture and organization II");
		s2.setSubCode("M2");
		s2.setClassroom("E2");
		s2.printInfo();
		
		Subject s3 = new Subject();
		s3.setSubDesc("Programming languages and software engineering II");
		s3.setSubCode("M3");
		s3.setClassroom("E3");
		s3.printInfo();
		
		Subject s4 = new Subject();
		s4.setSubDesc("Operating systems and networking II");
		s4.setSubCode("M4");
		s4.setClassroom("E1");
		s4.printInfo();
		
		Subject s5 = new Subject();
		s5.setSubDesc("Programming languages and software engineering III");
		s5.setSubCode("M5");
		s5.setClassroom("E3");
		s5.printInfo();
		
	
		Student m1 = new Student();
		m1.setFirstName("Luka");
		m1.setLaststName("Kotsiai");
		m1.setAMM("0702020");
		m1.setSubject("Algorithms and data structures");
		m1.setSubject("Computer architecture and organization");
		m1.setSubject("Programming languages and software engineering");
		m1.setSubject("Operating systems and networking");
		m1.setSubject("Artificial intelligence and machine learning");
		m1.printInfo();
		
		Student m2 = new Student();
		m2.setFirstName("Luka");
		m2.setLaststName("Kotsiai");
		m2.setAMM("0702020");
		m2.setSubject("Algorithms and data structures");
		m2.setSubject("Computer architecture and organization");
		m2.setSubject("Programming languages and software engineering");
		m2.setSubject("Operating systems and networking");
		m2.setSubject("Artificial intelligence and machine learning");
		m2.printInfo();
		
		Student m3 = new Student();
		m3.setFirstName("Luka");
		m3.setLaststName("Kotsiai");
		m3.setAMM("0702020");
		m3.setSubject("Algorithms and data structures");
		m3.setSubject("Computer architecture and organization");
		m3.setSubject("Programming languages and software engineering");
		m3.setSubject("Operating systems and networking");
		m3.setSubject("Artificial intelligence and machine learning");
		m3.printInfo();
		
		Student m4 = new Student();
		m4.setFirstName("Luka");
		m4.setLaststName("Kotsiai");
		m4.setAMM("0702020");
		m4.setSubject("Algorithms and data structures");
		m4.setSubject("Computer architecture and organization");
		m4.setSubject("Programming languages and software engineering");
		m4.setSubject("Operating systems and networking");
		m4.setSubject("Artificial intelligence and machine learning");
		m4.printInfo();
		
		Student m5 = new Student();
		m5.setFirstName("Luka");
		m5.setLaststName("Kotsiai");
		m5.setAMM("0702020");
		m5.setSubject("Algorithms and data structures");
		m5.setSubject("Computer architecture and organization");
		m5.setSubject("Programming languages and software engineering");
		m5.setSubject("Operating systems and networking");
		m5.setSubject("Artificial intelligence and machine learning");
		m5.printInfo();
		
		Student m6 = new Student();
		m6.setFirstName("Luka");
		m6.setLaststName("Kotsiai");
		m6.setAMM("0702020");
		m6.setSubject("Algorithms and data structures");
		m6.setSubject("Computer architecture and organization");
		m6.setSubject("Programming languages and software engineering");
		m6.setSubject("Operating systems and networking");
		m6.setSubject("Artificial intelligence and machine learning");
		m6.printInfo();
		
		Student m7 = new Student();
		m7.setFirstName("Luka");
		m7.setLaststName("Kotsiai");
		m7.setAMM("0702020");
		m7.setSubject("Algorithms and data structures");
		m7.setSubject("Computer architecture and organization");
		m7.setSubject("Programming languages and software engineering");
		m7.setSubject("Operating systems and networking");
		m7.setSubject("Artificial intelligence and machine learning");
		m7.printInfo();
		
		Student m8 = new Student();
		m8.setFirstName("Luka");
		m8.setLaststName("Kotsiai");
		m8.setAMM("0702020");
		m8.setSubject("Algorithms and data structures");
		m8.setSubject("Computer architecture and organization");
		m8.setSubject("Programming languages and software engineering");
		m8.setSubject("Operating systems and networking");
		m8.setSubject("Artificial intelligence and machine learning");
		m8.printInfo();
		
		Student m9 = new Student();
		m9.setFirstName("Luka");
		m9.setLaststName("Kotsiai");
		m9.setAMM("0702020");
		m9.setSubject("Algorithms and data structures");
		m9.setSubject("Computer architecture and organization");
		m9.setSubject("Programming languages and software engineering");
		m9.setSubject("Operating systems and networking");
		m9.setSubject("Artificial intelligence and machine learning");
		m9.printInfo();
		
		Student m10 = new Student();
		m10.setFirstName("Luka");
		m10.setLaststName("Kotsiai");
		m10.setAMM("0702020");
		m10.setSubject("Algorithms and data structures");
		m10.setSubject("Computer architecture and organization");
		m10.setSubject("Programming languages and software engineering");
		m10.setSubject("Operating systems and networking");
		m10.setSubject("Artificial intelligence and machine learning");
		m10.printInfo();
		
		Student m11 = new Student();
		m11.setFirstName("Luka");
		m11.setLaststName("Kotsiai");
		m11.setAMM("0702020");
		m11.setSubject("Algorithms and data structures");
		m11.setSubject("Computer architecture and organization");
		m11.setSubject("Programming languages and software engineering");
		m11.setSubject("Operating systems and networking");
		m11.setSubject("Artificial intelligence and machine learning");
		m11.printInfo();
		
		Student m12 = new Student();
		m12.setFirstName("Luka");
		m12.setLaststName("Kotsiai");
		m12.setAMM("0702020");
		m12.setSubject("Algorithms and data structures");
		m12.setSubject("Computer architecture and organization");
		m12.setSubject("Programming languages and software engineering");
		m12.setSubject("Operating systems and networking");
		m12.setSubject("Artificial intelligence and machine learning");
		m12.printInfo();
		
		Student m13 = new Student();
		m13.setFirstName("Luka");
		m13.setLaststName("Kotsiai");
		m13.setAMM("0702020");
		m13.setSubject("Algorithms and data structures");
		m13.setSubject("Computer architecture and organization");
		m13.setSubject("Programming languages and software engineering");
		m13.setSubject("Operating systems and networking");
		m13.setSubject("Artificial intelligence and machine learning");
		m13.printInfo();
		
		Student m14 = new Student();
		m14.setFirstName("Luka");
		m14.setLaststName("Kotsiai");
		m14.setAMM("0702020");
		m14.setSubject("Algorithms and data structures");
		m14.setSubject("Computer architecture and organization");
		m14.setSubject("Programming languages and software engineering");
		m14.setSubject("Operating systems and networking");
		m14.setSubject("Artificial intelligence and machine learning");
		m14.printInfo();
		
		Student m15 = new Student();
		m15.setFirstName("Luka");
		m15.setLaststName("Kotsiai");
		m15.setAMM("0702020");
		m15.setSubject("Algorithms and data structures");
		m15.setSubject("Computer architecture and organization");
		m15.setSubject("Programming languages and software engineering");
		m15.setSubject("Operating systems and networking");
		m15.setSubject("Artificial intelligence and machine learning");
		m15.printInfo();
		
		Student m16 = new Student();
		m16.setFirstName("Luka");
		m16.setLaststName("Kotsiai");
		m16.setAMM("0702020");
		m16.setSubject("Algorithms and data structures");
		m16.setSubject("Computer architecture and organization");
		m16.setSubject("Programming languages and software engineering");
		m16.setSubject("Operating systems and networking");
		m16.setSubject("Artificial intelligence and machine learning");
		m16.printInfo();
		
		Student m17 = new Student();
		m17.setFirstName("Luka");
		m17.setLaststName("Kotsiai");
		m17.setAMM("0702020");
		m17.setSubject("Algorithms and data structures");
		m17.setSubject("Computer architecture and organization");
		m17.setSubject("Programming languages and software engineering");
		m17.setSubject("Operating systems and networking");
		m17.setSubject("Artificial intelligence and machine learning");
		m17.printInfo();
		
		Student m18 = new Student();
		m18.setFirstName("Luka");
		m18.setLaststName("Kotsiai");
		m18.setAMM("0702020");
		m18.setSubject("Algorithms and data structures");
		m18.setSubject("Computer architecture and organization");
		m18.setSubject("Programming languages and software engineering");
		m18.setSubject("Operating systems and networking");
		m18.setSubject("Artificial intelligence and machine learning");
		m18.printInfo();
		
		Student m19 = new Student();
		m19.setFirstName("Luka");
		m19.setLaststName("Kotsiai");
		m19.setAMM("0702020");
		m19.setSubject("Algorithms and data structures");
		m19.setSubject("Computer architecture and organization");
		m19.setSubject("Programming languages and software engineering");
		m19.setSubject("Operating systems and networking");
		m19.setSubject("Artificial intelligence and machine learning");
		m19.printInfo();
		
		Student m20 = new Student();
		m20.setFirstName("Luka");
		m20.setLaststName("Kotsiai");
		m20.setAMM("0702020");
		m20.setSubject("Algorithms and data structures");
		m20.setSubject("Computer architecture and organization");
		m20.setSubject("Programming languages and software engineering");
		m20.setSubject("Operating systems and networking");
		m20.setSubject("Artificial intelligence and machine learning");
		m20.printInfo();
		

	}

}
